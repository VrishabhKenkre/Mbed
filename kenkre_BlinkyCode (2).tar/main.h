/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H_
#define __MAIN_H_

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_mort2.h"

/* MACROS for everyone--------------------------------------------------------*/



/*Function definitions---------------------------------------------------------*/



#ifdef __cplusplus
}
#endif

#endif /*__MAIN_H */
