#ifndef __DEBUG_MORT_H_
#define __DEBUG_MORT_H_

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/*Function definitions---------------------------------------------------------*/
void debugprint(uint16_t number);
void debugprintHelloWorld( void );

#ifdef __cplusplus
}
#endif

#endif /*__DEBUG_MORT_H */
